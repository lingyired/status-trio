// Controlled Metal GPU load generator for the M3 Max power measurement study.
// Research-only. Compiles the shader at runtime with device.makeLibrary(source:),
// so no xcrun metal, no .metallib files, and no extra software.
//
// Build:
//   clang -fobjc-arc -framework Foundation -framework Metal -o gpuload src/gpuload.m
// Usage:
//   gpuload --seconds 45 [--label name] [--grid 65536] [--inner 4096]
//   gpuload --seconds 0                      # run until signalled
//
// The kernel is a long dependent FMA chain per thread so the GPU stays busy for
// real arithmetic (not just scheduling overhead), and each dispatch is short
// enough (~ms) that SIGTERM stops it promptly.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <signal.h>
#import <stdatomic.h>
#import <time.h>
#import <unistd.h>

static volatile sig_atomic_t g_stop = 0;
static void on_signal(int sig) { (void)sig; g_stop = 1; }

static double now_mono(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static NSString *const kShader = @"#include <metal_stdlib>\n"
    "using namespace metal;\n"
    "kernel void burn(device float *out [[buffer(0)]],\n"
    "                 constant uint &inner [[buffer(1)]],\n"
    "                 uint gid [[thread_position_in_grid]]) {\n"
    "    float x = 1.0f + 1.0e-9f * float(gid);\n"
    "    float acc = 0.0f;\n"
    "    for (uint i = 0; i < inner; ++i) {\n"
    "        x = fma(x, 1.0000001f, 1.0e-9f);\n"
    "        if (x > 1.0e6f) { x = 1.0f + 1.0e-9f * float(gid); }\n"
    "        acc += x;\n"
    "    }\n"
    "    out[gid] = acc;\n"
    "}\n";

int main(int argc, char **argv) {
    long seconds = 45;
    NSUInteger grid = 65536;
    uint32_t inner = 4096;
    const char *label = "gpuload";

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--seconds") && i + 1 < argc) {
            seconds = atol(argv[++i]);
        } else if (!strcmp(argv[i], "--grid") && i + 1 < argc) {
            grid = (NSUInteger)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--inner") && i + 1 < argc) {
            inner = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--label") && i + 1 < argc) {
            label = argv[++i];
        } else {
            fprintf(stderr, "usage: %s --seconds N [--grid N] [--inner N] [--label name]\n", argv[0]);
            return 2;
        }
    }
    if (grid < 1024) grid = 1024;
    if (inner < 1) inner = 1;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    @autoreleasepool {
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (!device) {
            fprintf(stderr, "[gpuload] no Metal device\n");
            return 1;
        }
        NSError *err = nil;
        id<MTLLibrary> lib = [device newLibraryWithSource:kShader options:nil error:&err];
        if (!lib) {
            fprintf(stderr, "[gpuload] shader compile failed: %s\n",
                    err.localizedDescription.UTF8String);
            return 1;
        }
        id<MTLFunction> fn = [lib newFunctionWithName:@"burn"];
        id<MTLComputePipelineState> pipe = [device newComputePipelineStateWithFunction:fn error:&err];
        if (!pipe) {
            fprintf(stderr, "[gpuload] pipeline failed: %s\n", err.localizedDescription.UTF8String);
            return 1;
        }
        id<MTLCommandQueue> queue = [device newCommandQueue];

        NSUInteger bytes = grid * sizeof(float);
        id<MTLBuffer> out = [device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
        uint32_t innerCopy = inner;

        double start = now_mono();
        fprintf(stderr,
                "[gpuload] label=%s device=%s grid=%lu inner=%u seconds=%ld start_mono=%.3f pid=%d\n",
                label, device.name.UTF8String, (unsigned long)grid, inner, seconds, start,
                (int)getpid());

        unsigned long long dispatches = 0;
        while (!g_stop) {
            if (seconds > 0 && (now_mono() - start) >= (double)seconds) break;

            @autoreleasepool {
                id<MTLCommandBuffer> cb = [queue commandBuffer];
                id<MTLComputeCommandEncoder> enc = [cb computeCommandEncoder];
                [enc setComputePipelineState:pipe];
                [enc setBuffer:out offset:0 atIndex:0];
                [enc setBytes:&innerCopy length:sizeof(innerCopy) atIndex:1];
                NSUInteger tg = pipe.maxTotalThreadsPerThreadgroup;
                if (tg > 256) tg = 256;
                [enc dispatchThreads:MTLSizeMake(grid, 1, 1)
                    threadsPerThreadgroup:MTLSizeMake(tg, 1, 1)];
                [enc endEncoding];
                [cb commit];
                [cb waitUntilCompleted];
                if (cb.status == MTLCommandBufferStatusError) {
                    fprintf(stderr, "[gpuload] command buffer error: %s\n",
                            cb.error.localizedDescription.UTF8String);
                    return 1;
                }
            }
            dispatches++;
        }

        double stop = now_mono();
        fprintf(stderr, "[gpuload] stopped mono=%.3f elapsed=%.3f dispatches=%llu\n",
                stop, stop - start, dispatches);
    }
    return 0;
}
