// Bounded streaming memory-bandwidth load, 4 workers x 256 MiB by default.
// Research only; pthreads, no fork, no swap-sized allocation. SIGTERM/INT stop.
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t stop_flag = 0;
static void stop_handler(int s) { (void)s; stop_flag = 1; }
static double mono(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}
struct worker { float *a; size_t n; uint64_t bytes; double sink; };
static void *stream(void *p) {
    struct worker *w = p;
    uint64_t bytes = 0;
    while (!stop_flag) {
        // Read+write all elements. Per-thread array is much larger than SLC.
        for (size_t base = 0; base < w->n && !stop_flag; base += 262144) {
            size_t end = base + 262144;
            if (end > w->n) end = w->n;
            for (size_t j = base; j < end; ++j) w->a[j] = w->a[j] * 0.9999999f + 0.000001f;
            bytes += (end - base) * sizeof(float) * 2;
        }
    }
    w->sink = w->a[w->n / 2]; w->bytes = bytes;
    return NULL;
}
int main(int argc, char **argv) {
    int threads = 4, mib = 256; double seconds = 40;
    const char *label = "memload";
    for (int i=1; i<argc; ++i) {
        if (!strcmp(argv[i], "--threads") && i+1<argc) threads=atoi(argv[++i]);
        else if (!strcmp(argv[i], "--mib") && i+1<argc) mib=atoi(argv[++i]);
        else if (!strcmp(argv[i], "--seconds") && i+1<argc) seconds=atof(argv[++i]);
        else if (!strcmp(argv[i], "--label") && i+1<argc) label=argv[++i];
        else return 2;
    }
    if (threads<1 || threads>8 || mib<256 || mib>512 || seconds<0) return 2;
    struct sigaction sa={0}; sa.sa_handler=stop_handler;
    sigaction(SIGTERM,&sa,NULL); sigaction(SIGINT,&sa,NULL); sigaction(SIGHUP,&sa,NULL);
    pthread_t tids[8]; struct worker workers[8]={0};
    double start=mono(); int launched=0, rc=0;
    fprintf(stderr,"[memload] label=%s threads=%d mib_each=%d seconds=%.3f start_mono=%.6f pid=%d\n",label,threads,mib,seconds,start,getpid());
    for (int i=0; i<threads && !stop_flag; ++i) {
        size_t sz=(size_t)mib*1024*1024;
        if (posix_memalign((void **)&workers[i].a, 16384, sz)!=0) { rc=1; stop_flag=1; break; }
        workers[i].n=sz/sizeof(float);
        for (size_t j=0; j<workers[i].n; ++j) workers[i].a[j]=1.0f;
        if (pthread_create(&tids[i],NULL,stream,&workers[i])!=0) { free(workers[i].a); workers[i].a=NULL; rc=1; stop_flag=1; break; }
        ++launched;
    }
    while (!stop_flag && (seconds==0 || mono()-start<seconds)) usleep(20000);
    stop_flag=1;
    uint64_t bytes=0;
    for (int i=0; i<launched; ++i) { pthread_join(tids[i],NULL); bytes+=workers[i].bytes; free(workers[i].a); }
    double end=mono();
    fprintf(stderr,"[memload] stopped mono=%.6f elapsed=%.3f bytes_read_write=%llu effective_GBps=%.3f\n",end,end-start,(unsigned long long)bytes,bytes/1e9/(end-start));
    return rc;
}
