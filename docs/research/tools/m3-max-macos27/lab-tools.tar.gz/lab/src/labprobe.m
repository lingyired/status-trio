// Small environment probe used by run-scenarios.sh.
// Research-only, read-only. Exposes the same monotonic clock base to shell
// orchestration that the loaders and (per sensor-harness) the sampler use.
//
// Build: clang -fobjc-arc -framework Foundation -o labprobe src/labprobe.m
// Usage:
//   labprobe mono                       # monotonic seconds, one number
//   labprobe thermal                    # one JSON line
//   labprobe mark <label>               # JSON with mono + wall/ISO
#import <Foundation/Foundation.h>
#import <time.h>
#import <unistd.h>

static double now_mono(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc >= 2 && !strcmp(argv[1], "mono")) {
            printf("%.6f\n", now_mono());
            return 0;
        }
        if (argc >= 2 && !strcmp(argv[1], "thermal")) {
            NSProcessInfo *info = [NSProcessInfo processInfo];
            NSProcessInfoThermalState state = info.thermalState;
            const char *names[] = {"nominal", "fair", "serious", "critical"};
            int idx = (int)state;
            if (idx < 0 || idx > 3) idx = 0;
            printf("{\"mono\":%.6f,\"thermalState\":%d,\"thermalStateName\":\"%s\","
                   "\"lowPowerMode\":%s,\"wall\":\"%s\",\"pid\":%d}\n",
                   now_mono(), (int)state, names[idx],
                   info.isLowPowerModeEnabled ? "true" : "false",
                   [[[NSISO8601DateFormatter new] stringFromDate:[NSDate date]] UTF8String],
                   (int)getpid());
            return 0;
        }
        if (argc >= 2 && !strcmp(argv[1], "mark")) {
            const char *label = argc >= 3 ? argv[2] : "mark";
            NSDateFormatter *f = [NSDateFormatter new];
            f.dateFormat = @"yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ";
            printf("mark label=%s mono=%.6f wall=%s\n", label, now_mono(),
                   [[f stringFromDate:[NSDate date]] UTF8String]);
            return 0;
        }
        fprintf(stderr, "usage: %s mono|thermal|mark <label>\n", argv[0]);
        return 2;
    }
}
