// Read-only (and optionally set+restore) probe for built-in display brightness
// through the *public* IOKit IODisplay API shipped in the macOS SDK:
//   IODisplayGetFloatParameter / IODisplaySetFloatParameter, kIODisplayBrightnessKey
// No SMC writes, no private frameworks, no sudo.
//
// Build: clang -framework Foundation -framework IOKit -framework CoreGraphics \
//          -o brightness-probe src/brightness-probe.m
// Usage:
//   brightness-probe                  # read only
//   brightness-probe --set 0.3        # set, then restore the original value
#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <IOKit/graphics/IOGraphicsLib.h>
#import <CoreGraphics/CoreGraphics.h>
#include <unistd.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

static io_service_t mainDisplayService(void) {
    CGDirectDisplayID did = CGMainDisplayID();
    return CGDisplayIOServicePort(did);
}

int main(int argc, char **argv) {
    @autoreleasepool {
        double setTo = -1;
        for (int i = 1; i < argc; i++) {
            if (!strcmp(argv[i], "--set") && i + 1 < argc) setTo = atof(argv[++i]);
        }
        io_service_t svc = mainDisplayService();
        if (!svc) {
            fprintf(stderr, "RESULT=NO_DISPLAY_SERVICE\n");
            return 1;
        }
        CFTypeRef nameRef = IORegistryEntryCreateCFProperty(svc, CFSTR("IODisplayEDID"), kCFAllocatorDefault, 0);
        (void)nameRef;
        if (nameRef) CFRelease(nameRef);

        float value = 0;
        kern_return_t kr = IODisplayGetFloatParameter(svc, kNilOptions, CFSTR(kIODisplayBrightnessKey), &value);
        printf("READ kr=0x%x (0x%x=success) brightness=%.6f\n", kr, KERN_SUCCESS, value);
        if (kr != KERN_SUCCESS) {
            printf("RESULT=PUBLIC_API_UNSUPPORTED\n");
            return 0;
        }
        if (setTo >= 0) {
            float original = value;
            kern_return_t skr = IODisplaySetFloatParameter(svc, kNilOptions, CFSTR(kIODisplayBrightnessKey), setTo);
            printf("SET kr=0x%x target=%.3f\n", skr, setTo);
            usleep(300 * 1000);
            float after = 0;
            IODisplayGetFloatParameter(svc, kNilOptions, CFSTR(kIODisplayBrightnessKey), &after);
            printf("AFTER_SET brightness=%.6f\n", after);
            usleep(300 * 1000);
            kern_return_t rkr = IODisplaySetFloatParameter(svc, kNilOptions, CFSTR(kIODisplayBrightnessKey), original);
            printf("RESTORE kr=0x%x original=%.6f\n", rkr, original);
            usleep(300 * 1000);
            float restored = 0;
            IODisplayGetFloatParameter(svc, kNilOptions, CFSTR(kIODisplayBrightnessKey), &restored);
            printf("AFTER_RESTORE brightness=%.6f\n", restored);
            printf("RESULT=%s\n", (skr == KERN_SUCCESS && after < 0.9 * original + 0.05) ? "SET_OK" : "SET_FAILED");
        } else {
            printf("RESULT=READ_OK\n");
        }
    }
    return 0;
}
#pragma clang diagnostic pop
