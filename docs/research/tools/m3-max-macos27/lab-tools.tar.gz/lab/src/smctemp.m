// Read-only SMC temperature-key capability probe (research only).
// Reads a bounded candidate list of die-temperature keys; never writes SMC,
// never requests privileges, never enumerates the whole key table.
//
// Build: clang -framework Foundation -framework IOKit -o bin/smctemp src/smctemp.m
// Usage: smctemp            # probe candidate keys once
//        smctemp --hz 1 --seconds 30 --out temp.jsonl --label name   # sidecar
#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

static io_connect_t gConn = 0;

static uint32_t le32(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

typedef struct { int ok; uint32_t size; uint32_t type; uint8_t raw[32]; double value; const char *unit; } smcret;

static smcret readKeyFull(const char *key) {
    smcret r; memset(&r, 0, sizeof(r));
    uint8_t req[80] = {0}, res[80] = {0};
    size_t resSize = 80;
    if (strlen(key) != 4) return r;
    uint32_t word = ((uint32_t)key[0] << 24) | ((uint32_t)key[1] << 16) |
                    ((uint32_t)key[2] << 8) | (uint32_t)key[3];
    req[0] = word & 0xff; req[1] = (word >> 8) & 0xff;
    req[2] = (word >> 16) & 0xff; req[3] = (word >> 24) & 0xff;
    req[42] = 9;
    if (IOConnectCallStructMethod(gConn, 2, req, 80, res, &resSize) != KERN_SUCCESS || res[40] != 0) return r;
    uint32_t size = le32(res + 28), type = le32(res + 32);
    uint8_t sizeBytes[4] = { res[28], res[29], res[30], res[31] };
    memset(req, 0, 80); memset(res, 0, 80); resSize = 80;
    req[0] = word & 0xff; req[1] = (word >> 8) & 0xff;
    req[2] = (word >> 16) & 0xff; req[3] = (word >> 24) & 0xff;
    memcpy(req + 28, sizeBytes, 4);
    req[42] = 5;  // read bytes only (command 6 = write is never used)
    if (IOConnectCallStructMethod(gConn, 2, req, 80, res, &resSize) != KERN_SUCCESS || res[40] != 0) return r;
    r.ok = 1; r.size = size; r.type = type;
    if (size <= 32) memcpy(r.raw, res + 48, size);
    if (type == 0x666c7420 && size == 4) { float f; memcpy(&f, res + 48, 4); r.value = f; r.unit = "C"; }
    else if (type == 0x73703738 && size == 2) { int16_t raw = (int16_t)((res[48] << 8) | res[49]); r.value = raw / 256.0; r.unit = "C"; }
    else if (type == 0x75693136 && size == 2) { r.value = (double)((res[48] << 8) | res[49]); r.unit = "raw"; }
    else if (type == 0x75693820 && size == 1) { r.value = (double)res[48]; r.unit = "raw"; }
    else { r.value = 0; r.unit = "raw"; }
    return r;
}

// Community-known Apple Silicon candidate keys; semantics NOT verified on this
// machine. Kept small on purpose (no full enumeration).
static const char *kCandidates[] = {
    "Tp01","Tp05","Tp09","Tp0D","Tp0H","Tp0P","Tp0T","Tp0X","Tp0b","Tp0f",
    "Tg0a","Tg0b","Tg0L","Tg0T","Tg0f","Tg1a",
    "TB0T","TB1T","TB2T","TC0P","Te05","Te0L","Te0P","Te0S",
    NULL
};

static double now_mono(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(int argc, char **argv) {
    @autoreleasepool {
    double hz = 0; long seconds = 0; const char *out = NULL; const char *label = "temp";
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--hz") && i + 1 < argc) hz = atof(argv[++i]);
        else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atol(argv[++i]);
        else if (!strcmp(argv[i], "--out") && i + 1 < argc) out = argv[++i];
        else if (!strcmp(argv[i], "--label") && i + 1 < argc) label = argv[++i];
    }
    io_service_t service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("AppleSMC"));
    if (!service) { fprintf(stderr, "no AppleSMC\n"); return 1; }
    if (IOServiceOpen(service, mach_task_self(), 0, &gConn) != KERN_SUCCESS) { fprintf(stderr, "open failed\n"); return 1; }
    IOObjectRelease(service);

    if (hz <= 0 || seconds <= 0) {
        printf("%-5s %-6s %-4s %-10s %-12s %s\n", "key", "status", "size", "type", "value", "raw");
        for (int i = 0; kCandidates[i]; i++) {
            smcret r = readKeyFull(kCandidates[i]);
            char tbuf[5] = {0};
            tbuf[0] = (r.type >> 24) & 0xff; tbuf[1] = (r.type >> 16) & 0xff;
            tbuf[2] = (r.type >> 8) & 0xff; tbuf[3] = r.type & 0xff;
            char hex[96] = {0}, *p = hex;
            for (uint32_t b = 0; b < r.size && b < 32; b++) p += sprintf(p, "%02x", r.raw[b]);
            printf("%-5s %-6s %-4u %-10s %-12.3f %s\n", kCandidates[i],
                   r.ok ? "ok" : "fail", r.size, r.ok ? tbuf : "-", r.ok ? r.value : 0.0, hex);
        }
        return 0;
    }

    FILE *f = out ? fopen(out, "w") : stdout;
    if (!f) { perror("open out"); return 1; }
    double t0 = now_mono(); long n = 0;
    while (now_mono() - t0 < (double)seconds) {
        double ts = now_mono();
        fprintf(f, "{\"t_mono\":%.6f,\"label\":\"%s\",\"sample\":%ld,\"temp\":{", ts, label, n);
        int first = 1;
        for (int i = 0; kCandidates[i]; i++) {
            smcret r = readKeyFull(kCandidates[i]);
            if (!r.ok || (r.type != 0x666c7420 && r.type != 0x73703738)) continue;
            if (!first) fprintf(f, ",");
            first = 0;
            char tbuf[5] = {0};
            tbuf[0] = (r.type >> 24) & 0xff; tbuf[1] = (r.type >> 16) & 0xff;
            tbuf[2] = (r.type >> 8) & 0xff; tbuf[3] = r.type & 0xff;
            fprintf(f, "\"%s\":{\"value\":%.3f,\"type\":\"%s\"}", kCandidates[i], r.value, tbuf);
        }
        fprintf(f, "},\"thermal_state\":");
        NSProcessInfoThermalState st = [[NSProcessInfo processInfo] thermalState];
        fprintf(f, "%d}\n", (int)st);
        fflush(f);
        n++;
        usleep((useconds_t)(1e6 / hz));
    }
    if (out) fclose(f);
    fprintf(stderr, "[smctemp] wrote %ld samples in %.1fs\n", n, now_mono() - t0);
    }
    return 0;
}
