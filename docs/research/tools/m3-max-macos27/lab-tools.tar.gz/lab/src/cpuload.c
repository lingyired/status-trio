// Controlled CPU load generator for the M3 Max power measurement study.
// Research-only. Saturates N busy-loop threads; exits immediately on SIGTERM/SIGINT.
//
// Build:
//   clang -O2 -o cpuload src/cpuload.c
// Usage:
//   cpuload --threads 2 --seconds 45 [--label name]
//   cpuload --threads 6 --seconds 0      # run until signalled
//
// Design notes:
//   * Dependent floating-point chain so the loop cannot be vectorised away,
//     and the accumulator is published to a volatile sink so it is not DCE'd.
//   * One pthread per worker, pinned by the kernel scheduler; thread count is
//     clamped to 8 to stay a "light" synthetic load on a 12P+4E machine.
//   * The signal handler only sets a sig_atomic_t flag; workers poll it every
//     inner iteration (cheap) so shutdown latency is well under a millisecond.
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_THREADS 8

static volatile sig_atomic_t g_stop = 0;
static volatile double g_sink = 0.0;

static void on_signal(int sig) { (void)sig; g_stop = 1; }

static double now_mono(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

struct worker_arg {
    int index;
    unsigned long long iterations;
};

static void *worker(void *raw) {
    struct worker_arg *arg = (struct worker_arg *)raw;
    double x = 1.0 + 1e-9 * (double)arg->index;
    double acc = 0.0;
    unsigned long long iters = 0;
    while (!g_stop) {
        // ~4096 dependent FMAs per poll of the stop flag.
        for (int i = 0; i < 4096; i++) {
            x = x * 1.0000000001 + 1e-12;
            if (x > 1e6) x = 1.0 + 1e-9 * (double)arg->index;
            acc += x;
        }
        iters += 4096;
    }
    g_sink = acc;  // publish so the compiler keeps the work
    arg->iterations = iters;
    return NULL;
}

int main(int argc, char **argv) {
    int threads = 2;
    long seconds = 45;
    const char *label = "cpuload";

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            threads = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) {
            seconds = atol(argv[++i]);
        } else if (!strcmp(argv[i], "--label") && i + 1 < argc) {
            label = argv[++i];
        } else {
            fprintf(stderr, "usage: %s --threads N --seconds N [--label name]\n", argv[0]);
            return 2;
        }
    }
    if (threads < 1) threads = 1;
    if (threads > MAX_THREADS) threads = MAX_THREADS;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    pthread_t tids[MAX_THREADS];
    struct worker_arg args[MAX_THREADS];
    for (int i = 0; i < threads; i++) {
        args[i].index = i;
        args[i].iterations = 0;
        if (pthread_create(&tids[i], NULL, worker, &args[i]) != 0) {
            fprintf(stderr, "cpuload: pthread_create failed (%s)\n", strerror(errno));
            g_stop = 1;
            for (int j = 0; j < i; j++) pthread_join(tids[j], NULL);
            return 1;
        }
    }

    double start = now_mono();
    fprintf(stderr,
            "[cpuload] label=%s threads=%d seconds=%ld start_mono=%.3f pid=%d\n",
            label, threads, seconds, start, (int)getpid());

    if (seconds > 0) {
        while (!g_stop) {
            double elapsed = now_mono() - start;
            if (elapsed >= (double)seconds) break;
            struct timespec req = {0, 50 * 1000 * 1000};  // 50 ms
            nanosleep(&req, NULL);
        }
        g_stop = 1;
    } else {
        while (!g_stop) {
            struct timespec req = {0, 50 * 1000 * 1000};
            nanosleep(&req, NULL);
        }
    }

    for (int i = 0; i < threads; i++) pthread_join(tids[i], NULL);

    unsigned long long total = 0;
    for (int i = 0; i < threads; i++) total += args[i].iterations;
    double stop = now_mono();
    fprintf(stderr, "[cpuload] stopped mono=%.3f elapsed=%.3f iters=%llu sink=%.3f\n",
            stop, stop - start, total, g_sink);
    return 0;
}
