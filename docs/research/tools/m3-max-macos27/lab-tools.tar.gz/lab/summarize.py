#!/usr/bin/env python3
"""Experiment-specific report: active windows, load-off edges, GPU cross-check."""
import json, pathlib, re, statistics as st, math, importlib.util
ROOT=pathlib.Path('/Users/lingsmbp/Documents/aiwork/status-trio/.worktrees/battery-power-breakdown/docs/research/data/m3-max-macos27')
LAB=pathlib.Path('/tmp/soc-power-research/lab')
spec=importlib.util.spec_from_file_location('analysis',LAB/'analyze.py'); a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

def mean(xs):return st.fmean(xs) if xs else None
def fmt(x):return 'NA' if x is None else f'{x:.3f}'
def corr(x,y):
 if len(x)<3:return None
 mx,my=mean(x),mean(y); dx=sum((v-mx)**2 for v in x);dy=sum((v-my)**2 for v in y)
 return sum((u-mx)*(v-my) for u,v in zip(x,y))/math.sqrt(dx*dy) if dx*dy>0 else None

def unpack(r):
 out={'t':r['ts_mono'],'thermal':r['thermal_state']}
 for e in r['smc']:
  if e.get('status')=='ok' and isinstance(e.get('value'),(int,float)):out[e['key']]=e['value']
 for e in r['clpc']['channels']:
  name=e['channel'];out['CLPC/'+name]=e.get('power_w_estimate');out['raw/'+name]=int(e['raw_count_decimal'])
 for e in r['ioreport']['channels']:
  if e.get('group')=='Energy Model' and e.get('channel')=='GPU Energy' and e.get('unit')=='nJ':out['EM/GPU']=e.get('power_w_estimate')
 pb=r.get('pmset_batt',{});out['charge']=a.battery_charge_w(pb);out['usb']=a.usb_out_w(pb)
 if all(k in out for k in ('PDTR','PDBR','PHPC')):
  out['residual_USB_assumed0']=out['PDTR']-out['PDBR']-out['PHPC']-(out['charge'] or 0)
 return out

def vals(rows,k):return [r[k] for r in rows if isinstance(r.get(k),(int,float))]
def window_mean(rows,k):return mean(vals(rows,k))

boundaries=(ROOT/'_orchestration/boundaries.log').read_text()
phases={}
for line in boundaries.splitlines():
 m=re.search(r'mono=([0-9.]+).*LOAD_START name=(\S+)',line)
 if m:phases.setdefault(m[2],{})['load_start']=float(m[1])
for name in phases:
 log=ROOT/'_orchestration'/f'{name}.log'
 if log.exists():
  txt=log.read_text(); starts=re.findall(r'start_mono=([0-9.]+)',txt);ends=re.findall(r'stopped mono=([0-9.]+)',txt)
  if starts:phases[name]['load_start']=min(map(float,starts))
  if ends:phases[name]['load_stop']=max(map(float,ends))

data={}; originals={}
for f in sorted(ROOT.glob('*.jsonl')):
 if f.name.startswith('temp-'):continue
 original=[json.loads(l) for l in f.read_text().splitlines() if l.strip()]
 if not original:continue
 name=original[0]['label'];originals[name]=original; data[name]=[unpack(r) for r in original]

L=['# M3 Max / macOS 27.2 受控负载实验分析','',
'本报告区分「实测」「推测」与「NOT TESTED」。后台应用保持运行，基线只是未主动加压。各负载阶段均保留停载后 5 秒左右原始样本。',
'', '## 关键数值（实测）','',
'**窗口规则**：有生成器日志的阶段取 `[生成器 start_mono, 生成器 stop_mono]`（排除停载尾部）；idle/recovery 这类不施加负载的阶段没有生成器日志，取该文件**全部样本**，不截断。每行标注实际样本 n。','',
'| 场景 | 窗口规则 | 样本n | PHPC W | CLPC CPU W | CLPC GPU W | CLPC ANE窗口 W | CLPC和 W | PHPC−CLPC和 W | EM GPU W | PDBR W | 残差* W |','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
summary={}
for name,rows in data.items():
 p=phases.get(name,{})
 if 'load_start' in p and 'load_stop' in p:
  rule='load';active=[r for r in rows if r['t']>=p['load_start'] and r['t']<=p['load_stop']]
 else:
  rule='full';active=rows
 if not active:rule='full(fallback)';active=rows
 # cumulative component means with one common endpoint window
 elapsed=active[-1]['t']-active[0]['t']
 cs={}
 for k in ('CPU Energy','GPU Energy','ANE'):
  raw='raw/'+k
  cs[k]=(active[-1][raw]-active[0][raw])/1e9/elapsed if elapsed>0 and raw in active[0] and raw in active[-1] else None
 total=sum(cs.values()) if all(x is not None for x in cs.values()) else None
 php=window_mean(active,'PHPC');res=window_mean(active,'residual_USB_assumed0')
 extra={k:window_mean(active,k) for k in ('PZC0','PHPS','PP0b','PP7b')}
 summary[name]={'active_n':len(active),'extra_smc':extra,'PHPC':php,'CLPC':cs,'CLPC_sum':total,'PHPC_minus_CLPC':php-total if total is not None else None,'EM_GPU':window_mean(active,'EM/GPU'),'PDBR':window_mean(active,'PDBR'),'residual':res,'active_start':active[0]['t'],'active_stop':active[-1]['t'],'thermal':dict(__import__('collections').Counter(r['thermal'] for r in rows))}
 s=summary[name]
 summary[name]['window_rule']=rule;summary[name]['window_n']=len(active)
 L.append('| '+' | '.join([name,rule,str(len(active)),fmt(php),fmt(cs['CPU Energy']),fmt(cs['GPU Energy']),fmt(cs['ANE']),fmt(total),fmt(s['PHPC_minus_CLPC']),fmt(s['EM_GPU']),fmt(s['PDBR']),fmt(res)])+' |')
L+=['','*残差使用 PDTR−charge−PDBR−PHPC，USB PowerOutDetails 缺失时仅作 USB=0 的条件估算。未取得 B0AC/B0AV，因此 charge 用 AppleSmartBattery IsCharging/电流/电压代理，不能把未知 USB 严格认证为 0 W。','',
'## 各阶段其余 SMC 功率键（实测，窗口规则同上）','',
'PPbb 全程不可用（读 info 返回 SMC result 132），不补值。','',
'| 场景 | 窗口规则 | 样本n | PZC0 W | PHPS W | PP0b W | PP7b W |','|---|---|---:|---:|---:|---:|---:|']
for name in list(data):
 s_=summary[name];e=s_['extra_smc']
 L.append('| '+' | '.join([name,s_['window_rule'],str(s_['window_n'])]+[fmt(e.get(k)) for k in ('PZC0','PHPS','PP0b','PP7b')])+' |')
L+=['','## 同阶段停载成对边沿（实测）','',
'窗口：停载前最后 5 秒（排除边沿前 1 秒）与停载后 1–5 秒，后者的差分功率区间完全在停载后。负值表示功率/温度回落；后台负载可能同时变化。','',
'| 场景 | 停载 mono | 前/后样本n | ΔPHPC W | ΔCLPC CPU W | ΔCLPC GPU W | ΔEM GPU W | ΔPCPU °C | ΔGPU °C |','|---|---:|---|---:|---:|---:|---:|---:|---:|']
for name,rows in data.items():
 stop=phases.get(name,{}).get('load_stop')
 if not stop:continue
 pre=[r for r in rows if stop-6<=r['t']<=stop-1];post=[r for r in rows if stop+1<=r['t']<=stop+5.5]
 diffs={}
 for k in ('PHPC','CLPC/CPU Energy','CLPC/GPU Energy','EM/GPU','Tf04','Tf14'):
  x,y=window_mean(pre,k),window_mean(post,k);diffs[k]=y-x if x is not None and y is not None else None
 summary[name]['load_stop']=stop;summary[name]['edge_deltas']=diffs
 L.append('| '+' | '.join([name,f'{stop:.6f}',f'{len(pre)}/{len(post)}']+[fmt(diffs[k]) for k in diffs])+' |')
L+=['','## native EM GPU 与 CLPC GPU 同秒互校（实测）','',
'两路 power_w_estimate 来自同一个采样 interval；保留逐秒对照 CSV。相关系数与差值只说明趋势/一致程度，不证明两条通道功率边界相同。','',
'| 场景 | 配对n | EM GPU均值 W | CLPC GPU均值 W | CLPC−EM W | 相对EM差% | Pearson r | MAE W |','|---|---:|---:|---:|---:|---:|---:|---:|']
csv=['scenario,ts_mono,native_EM_GPU_W,CLPC_GPU_W,difference_W']
for name,rows in data.items():
 pairs=[(r['EM/GPU'],r['CLPC/GPU Energy'],r['t']) for r in rows if isinstance(r.get('EM/GPU'),(int,float)) and isinstance(r.get('CLPC/GPU Energy'),(int,float))]
 if not pairs:continue
 x=[p[0] for p in pairs];y=[p[1] for p in pairs];mx,my=mean(x),mean(y)
 s={'n':len(pairs),'EM':mx,'CLPC':my,'difference':my-mx,'relative_pct':100*(my-mx)/mx if mx else None,'r':corr(x,y),'MAE':mean([abs(a-b) for a,b,_ in pairs])}
 summary[name]['gpu_crosscheck']=s
 L.append('| '+' | '.join([name,str(len(pairs))]+[fmt(s[k]) for k in ('EM','CLPC','difference','relative_pct','r','MAE')])+' |')
 csv.extend(f'{name},{t:.6f},{x:.9f},{y:.9f},{y-x:.9f}' for x,y,t in pairs)
(ROOT/'gpu-crosscheck.csv').write_text('\n'.join(csv)+'\n')
L+=['','## PDTR 与 PSTR 的时序（实测）','',
'以下按样本延迟 k 比较 PSTR[t] 与 PDTR[t−k]，最小均方根误差代表本次最接近的时序；1Hz 只能分辨整秒，不能证明亚秒固定延迟。','',
'| 场景 | 最佳滞后样本/约秒 | RMSE W | r |','|---|---:|---:|---:|']
for name,rows in data.items():
 candidates=[]
 for lag in range(-4,5):
  pairs=[(rows[i]['PSTR'],rows[i-lag]['PDTR']) for i in range(len(rows)) if 0<=i-lag<len(rows) and 'PSTR' in rows[i] and 'PDTR' in rows[i-lag]]
  if len(pairs)>5:
   err=math.sqrt(mean([(x-y)**2 for x,y in pairs]));candidates.append((err,lag,corr([x for x,y in pairs],[y for x,y in pairs])))
 if candidates:
  err,lag,r=min(candidates);summary[name]['PDTR_PSTR_lag']={'lag_samples':lag,'RMSE':err,'r':r}
  L.append(f'| {name} | {lag} | {err:.3f} | {fmt(r)} |')
L+=['','## 残差与热状态（实测）','',
'| 场景 | 残差min/max W | 负样本n/全部 | 低于−0.75W样本 | thermalState | PCPU温度min/max °C | GPU温度min/max °C |','|---|---|---|---:|---|---|---|']
for name,rows in data.items():
 v=vals(rows,'residual_USB_assumed0');cpu=vals(rows,'Tf04');gpu=vals(rows,'Tf14')
 if not v:continue
 L.append(f"| {name} | {min(v):.2f}/{max(v):.2f} | {sum(x<0 for x in v)}/{len(v)} | {sum(x<-.75 for x in v)} | {summary[name]['thermal']} | {min(cpu):.1f}/{max(cpu):.1f} | {min(gpu):.1f}/{max(gpu):.1f} |")
(LAB/'key-results.md').write_text('\n'.join(L)+'\n')
(LAB/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
# Complete per-channel descriptive statistics include the full recorded phase,
# including baseline sample and post-load tail; main table above uses active only.
allL=[]
for name,orig in originals.items():
 d=a.collect(orig);allL += [f'## {name}（含停载尾部全部记录）','']
 allL+=a.table('SMC 功率键',d['smc'],unit='W')
 missing=[k for k in a.SMC_KEYS if not d['smc'].get(k)]
 if missing:allL += ['缺失 SMC：'+', '.join(missing)+'；不补零。','']
 allL+=a.table('CLPC（仅有有效差分功率的区间）',d['clpc'],unit='W')
 allL+=a.table('IOReport（按 group/channel 区分）',d['ioreport'],unit='W')
 allL+=a.table('M3温度 Te05=ECPU1 / Tf04=PCPU1 / Tf14=GPU1',d['smctemp'],unit='°C')
(LAB/'full-statistics.md').write_text('\n'.join(allL))
print('\n'.join(L[:20]))
