#!/usr/bin/env python3
import pathlib,datetime,json,hashlib,subprocess,re
R=pathlib.Path('/Users/lingsmbp/Documents/aiwork/status-trio/.worktrees/battery-power-breakdown/docs/research/data/m3-max-macos27')
H=pathlib.Path('/tmp/soc-power-research/harness'); LAB=pathlib.Path('/tmp/soc-power-research/lab')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
L=['# 受控负载实验原始数据清单','',
'- 时区 Asia/Shanghai (+08:00)；绝对时间见各文件名的时间戳与 _orchestration/boundaries.log。',
'- Mac15,9 / M3 Max / 12P+4E / 128GB / macOS 27.2 (26B123)。',
'- AC接电，开始时80%且未充电；内建屏在线，亮度不改变。',
'- 后台应用维持现状；Stats.app、macpow未停止。',
'- 唯一仓库写入范围为本目录；实验工具与分析在 /tmp/soc-power-research/lab/。',
'- 无sudo、无SMC写入、未安装软件、未改系统设置、未提交git。','',
'## 采样器版本与命令','',
'- schema: soc-power-research/1，默认17通道（原生Energy Model 14 + CLPC 3）。',
f'- 二进制 SHA256: `{sha(H/"power-sampler")}`',
f'- 源码 SHA256: `{sha(H/"power-sampler.m")}`',
'- 命令：`power-sampler --hz 1 --seconds <phase-duration+5> --out <scenario>-20261030T230326.jsonl --label <scenario>`',
'- 单调时钟：CLOCK_MONOTONIC，加载器/编排labprobe/采样器共享同一系统基准。',
'- CPU: cpuload 2线程45s、6线程60s；GPU: Metal运行期源码编译，grid65536×inner4096，55s。',
'- 内存: memload 4线程×256MiB，总1GiB，40s；向量读写，校验约186.7GB/s。',
'- 混合: cpuload 4线程 + gpuload，55s。',
'- 阶段间10秒缓冲，负载结束后同场景继续采样5秒；所有原始样本均保留。','',
'## 阶段边界（mono 秒）','',
'下表PHASE_START包含快照/热检查准备时间；精确LOAD_START/STOP来自生成器日志。完整边界见 _orchestration/boundaries.log。','',
'| 场景 | phase_start | load_start | load_stop | phase_end | 样本数 | ts_mono首/末 |','|---|---:|---:|---:|---:|---:|---|']
b=(R/'_orchestration/boundaries.log').read_text();phase={}
for line in b.splitlines():
 m=re.search(r'mono=([0-9.]+) (PHASE_START|PHASE_END|LOAD_START) name=(\S+)',line)
 if m:phase.setdefault(m[3],{})[m[2]]=float(m[1])
for f in sorted(R.glob('*.jsonl')):
 rows=[json.loads(x) for x in f.read_text().splitlines() if x.strip()];n=rows[0]['label'];p=phase.get(n,{})
 log=R/'_orchestration'/f'{n}.log';starts=[];ends=[]
 if log.exists():
  txt=log.read_text();starts=re.findall(r'start_mono=([0-9.]+)',txt);ends=re.findall(r'stopped mono=([0-9.]+)',txt)
 ls=min(map(float,starts)) if starts else None;le=max(map(float,ends)) if ends else None
 fmt=lambda x:'—' if x is None else f'{x:.6f}'
 L.append('| '+' | '.join([n,fmt(p.get('PHASE_START')),fmt(ls),fmt(le),fmt(p.get('PHASE_END')),str(len(rows)),f"{rows[0]['ts_mono']:.6f}/{rows[-1]['ts_mono']:.6f}"])+' |')
L+=['','## 后台与热状态快照','',
'- 每阶段开始/中段/结束的ps：`_orchestration/ps-snapshots/`。',
'- 热状态变化：`_orchestration/thermal.jsonl`；每秒看门狗，中止阈值serious/critical。',
'- M3温度实际值位于各JSONL的smc数组：Te05 ECPU1、Tf04 PCPU1、Tf14 GPU1（Stats M3映射；传感器能力报告见 /tmp/soc-power-research/harness/capabilities.md）。',
'- 每秒GPU Device Utilization：`_orchestration/gpu-util.tsv`。',
'- 两GPU通道逐秒差分对照：`gpu-crosscheck.csv`。','',
'### 开始时背景（完整初始ps快照另存）','','```',
(R/'_orchestration/ps-snapshots/00-run-start.txt').read_text(),'```','',
'## 异常 / NOT TESTED','',
'- brightness: NOT TESTED。用户禁止系统设置变更；公开API只读探测返回NO_DISPLAY_SERVICE，未尝试调亮度；无法验证PDBR/PHPC的亮度串扰。',
'- 无干净空闲；后台GPU基线已高且不同阶段发生变化，只把阶段均值作为本次环境观察。',
'- ANE未安排隔离负载；计数偶尔增长不能确定来源，更不能确认PHPC是否覆盖ANE。',
'- USB PowerOutDetails在所有样本缺失；残差采用USB=0的条件估算，不作为完整边界的严格验证。',
'- 充电为IsCharging=false，未读取SMC B0AC/B0AV；充电功率使用AppleSmartBattery代理。',
'- PPbb不可用；原生EM CPU/ANE/DRAM/DISP等13/14通道冻结，不补为0W。',
'- 风扇声音/真人感知卡顿无自动传感器证据，不声称已测；thermal看门狗与温度保留。',
'- PDBR随背景内容/实际背光变化，不能当作受控亮度常量。','',
'## 边界日志','', '完整逐行记录（含 PHASE_START/LOAD_START/LOAD_STOP/MID_SNAPSHOT/BUFFER）：`_orchestration/boundaries.log`。','',
'## 数据SHA256','', '| 文件 | 字节数 | SHA256 |','|---|---:|---|']
for f in sorted(R.glob('*.jsonl')):L.append(f'| {f.name} | {f.stat().st_size} | {sha(f)} |')
(R/'manifest.md').write_text('\n'.join(L)+'\n')
print('wrote manifest.md')
