#!/usr/bin/env python3
import pathlib,json,statistics as s,re,math
R=pathlib.Path('/Users/lingsmbp/Documents/aiwork/status-trio/.worktrees/battery-power-breakdown/docs/research/data/m3-max-macos27');L=pathlib.Path('/tmp/soc-power-research/lab')
summary=json.loads((L/'summary.json').read_text()); out=[]
util={}
for line in (R/'_orchestration/gpu-util.tsv').read_text().splitlines():
 try:t,n,v=line.split('\t');util.setdefault(n,[]).append(float(v))
 except:pass
out+=['## GPU 持续利用率（实测，ioreg 每秒读一次）','','| 场景 | n | mean % | min/max % | ≥90%比例 |','|---|---:|---:|---|---:|']
for n,v in util.items():out.append(f'| {n} | {len(v)} | {s.fmean(v):.1f} | {min(v):.0f}/{max(v):.0f} | {sum(x>=90 for x in v)/len(v)*100:.1f}% |')
out+=['','## 停载电响应与热响应（实测时间线）','',
'每行的相对时间以生成器报告的退出单调时间为0；负数是负载末尾，正数是停载后。原始功率波动大，样本之间有1秒量化；不拟合单一指数，不把名义 thermalState 误作芯片温度。','']
for f in sorted(R.glob('*.jsonl')):
 rows=[json.loads(x) for x in f.read_text().splitlines() if x.strip()];n=rows[0]['label'];stop=summary.get(n,{}).get('load_stop')
 if not stop:continue
 out += [f'### {n} 停载附近','','| t−停载 s | PHPC W | CLPC CPU W | CLPC GPU W | PCPU °C | GPU °C |','|---:|---:|---:|---:|---:|---:|']
 for r in rows:
  dt=r['ts_mono']-stop
  if not -6<=dt<=6:continue
  sm={e['key']:e.get('value') for e in r['smc']};cl={e['channel']:e.get('power_w_estimate') for e in r['clpc']['channels']}
  fs=lambda v:'NA' if v is None else f'{v:.2f}'
  out.append('| '+' | '.join([f'{dt:.2f}',fs(sm.get('PHPC')),fs(cl.get('CPU Energy')),fs(cl.get('GPU Energy')),fs(sm.get('Tf04')),fs(sm.get('Tf14'))])+' |')
# count and freeze matrix native channels
out+=['','## 缺失与冻结通道','','原生 Energy Model 通道的冻结性按本轮每场景首末 raw_count_decimal 比较，累计计数不变不可解释为0 W。','',
'| 场景 | 原生EM不变/总通道 | CLPC ANE增量 nJ | USB字段存在样本 | 充电样本 | 采样间隔min/max s |','|---|---|---:|---:|---:|---|']
for f in sorted(R.glob('*.jsonl')):
 rows=[json.loads(x) for x in f.read_text().splitlines() if x.strip()];n=rows[0]['label'];first,last=rows[0],rows[-1]
 em=lambda r:{e['id']:int(e['raw_count_decimal']) for e in r['ioreport']['channels'] if e.get('group')=='Energy Model'}
 x,y=em(first),em(last);same=sum(v==y.get(k) for k,v in x.items())
 an=lambda r:next(int(e['raw_count_decimal']) for e in r['clpc']['channels'] if e['channel']=='ANE')
 it=[r['sampling']['interval_s'] for r in rows if r['sampling'].get('interval_s') is not None]
 out.append(f"| {n} | {same}/{len(x)} | {an(last)-an(first)} | {sum('PowerOutDetails' in r.get('pmset_batt',{}) for r in rows)} | {sum(bool(r.get('pmset_batt',{}).get('IsCharging')) for r in rows)} | {min(it):.4f}/{max(it):.4f} |")
(L/'diagnostics.md').write_text('\n'.join(out)+'\n')
print('\n'.join(out[:17]))
