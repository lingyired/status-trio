#!/bin/bash
# Build the three load generators plus the environment probe.
# Research-only; binaries land in /tmp/soc-power-research/lab/bin/.
set -euo pipefail

LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$LAB_DIR/src"
BIN="$LAB_DIR/bin"
mkdir -p "$BIN"

echo "[build] clang version: $(clang --version | head -1)"
clang -O2 -Wall -Wextra -o "$BIN/cpuload" "$SRC/cpuload.c"
echo "[build] cpuload OK"

clang -O2 -fobjc-arc -Wall -Wextra -framework Foundation -framework Metal \
    -o "$BIN/gpuload" "$SRC/gpuload.m"
echo "[build] gpuload OK"

clang -O2 -fobjc-arc -Wall -Wextra -framework Foundation \
    -o "$BIN/labprobe" "$SRC/labprobe.m"
echo "[build] labprobe OK"

ls -l "$BIN"
