#!/usr/bin/env python3
"""Statistics for the controlled-load power experiment (sensor-harness schema).

Reads per-scenario JSONL from the status-trio research data directory and emits
a Chinese markdown statistics report: for every SMC key, CLPC channel, IOReport
power channel and (optional) chip-temperature sidecar key it reports
mean/median/max/min/n. It also derives:
  * residual = PDTR - charge - PDBR - PHPC - USB   (charge from pmset, USB from
    AppleSmartBattery PowerOutDetails when present)
  * thermal_state distribution per scenario
  * deltas vs the idle baseline

Schema tolerance:
  * ioreport power accepts `power_w_estimate` (W) or `power_kw_estimate` (kW).
  * clpc power uses `power_w_estimate`.
  * smc[] entries carry {key, value, status, type}.
  * temperature sidecars are temp-<phase>-*.jsonl with {"temp": {"Tp05": {...}}}.

Usage:
  ./analyze.py <data-dir> [--out report.md] [--baseline 01-idle-baseline]
"""
import argparse
import glob
import json
import os
import statistics
import sys
from collections import Counter

SMC_KEYS = ["PHPC", "PZC0", "PHPS", "PSTR", "PDTR", "PDBR", "PP0b", "PPbb", "PP7b"]
# Source-confirmed M3 die temps from harness (Stats values.swift):
#   Te05=ECPU1, Tf04=PCPU1, Tf14=GPU1. Battery temps TB*T are informational.
TEMP_KEY_HINTS = {"Te05", "Tf04", "Tf14", "TB0T", "TB1T", "TB2T"}


def fnum(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def load(path):
    out = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def ioreport_power_w(c):
    w = fnum(c.get("power_w_estimate"))
    if w is not None:
        return w
    kw = fnum(c.get("power_kw_estimate"))
    if kw is not None:
        return kw * 1000.0
    return None


def battery_charge_w(pb):
    if not isinstance(pb, dict):
        return None
    if not pb.get("IsCharging"):
        return 0.0
    amp = fnum(pb.get("InstantAmperage"))
    if amp is None:
        amp = fnum(pb.get("Amperage"))
    volt = fnum(pb.get("Voltage"))
    if amp is None or volt is None:
        return None
    return max(0.0, amp * volt / 1e6)


def usb_out_w(pb):
    if not isinstance(pb, dict):
        return None
    pod = pb.get("PowerOutDetails")
    if not isinstance(pod, list) or not pod:
        return None
    total = 0.0
    for item in pod:
        if isinstance(item, dict):
            w = fnum(item.get("Watts"))
            if w is None:
                mw = fnum(item.get("PDPowermW"))
                w = mw / 1000.0 if mw is not None else 0.0
            total += w
    return total


def collect(records):
    smc = {k: [] for k in SMC_KEYS}
    clpc, ioreport = {}, {}
    residual, charge, usb, intervals = [], [], [], []
    smctemp = {}
    therm = Counter()

    for r in records:
        if isinstance(r.get("thermal_state"), str):
            therm[r["thermal_state"]] += 1
        s = r.get("sampling")
        if isinstance(s, dict) and isinstance(s.get("interval_s"), (int, float)):
            intervals.append(float(s["interval_s"]))

        row_smc = {}
        for e in r.get("smc", []) or []:
            if not isinstance(e, dict):
                continue
            v = fnum(e.get("value"))
            if e.get("status") == "ok" and v is not None:
                key = e.get("key")
                unit = str(e.get("unit_inferred") or e.get("unit") or "")
                if "°C" in unit or key in TEMP_KEY_HINTS:
                    smctemp.setdefault(key, []).append(v)
                else:
                    row_smc[key] = v
                    smc.setdefault(key, []).append(v)

        for c in (r.get("clpc", {}) or {}).get("channels", []) or []:
            name = c.get("channel") if isinstance(c, dict) else None
            v = fnum(c.get("power_w_estimate")) if isinstance(c, dict) else None
            if name and v is not None:
                clpc.setdefault(name, []).append(v)

        for c in (r.get("ioreport", {}) or {}).get("channels", []) or []:
            if not isinstance(c, dict):
                continue
            ch_name = (c.get("channel") or "").strip()
            grp = (c.get("group") or "").strip()
            name = f"{grp}/{ch_name}" if grp else ch_name
            v = ioreport_power_w(c)
            if ch_name and v is not None:
                ioreport.setdefault(name, []).append(v)

        pb = r.get("pmset_batt")
        ch, ub = battery_charge_w(pb), usb_out_w(pb)
        if ch is not None:
            charge.append(ch)
        if ub is not None:
            usb.append(ub)
        if all(k in row_smc for k in ("PDTR", "PDBR", "PHPC")):
            residual.append(row_smc["PDTR"] - (ch or 0.0) - row_smc["PDBR"]
                            - row_smc["PHPC"] - (ub or 0.0))

    return {"smc": smc, "smctemp": smctemp, "clpc": clpc, "ioreport": ioreport, "residual": residual,
            "charge": charge, "usb": usb, "therm": therm,
            "intervals": intervals, "n": len(records)}


def collect_temp(path):
    """Temperature sidecar -> {key: [values]}."""
    out = {}
    for r in load(path):
        for k, v in (r.get("temp") or {}).items():
            val = fnum(v.get("value")) if isinstance(v, dict) else fnum(v)
            if val is not None:
                out.setdefault(k, []).append(val)
    return out


def st(vals):
    if not vals:
        return None
    return dict(n=len(vals), mean=statistics.fmean(vals), median=statistics.median(vals),
                max=max(vals), min=min(vals))


def table(title, series, prec=3, unit=""):
    lines = [f"### {title}{(' (' + unit + ')') if unit else ''}", "",
             "| 通道 | n | mean | median | max | min |", "|---|---|---|---|---|---|"]
    rows = 0
    for k in series:
        s = st(series[k]) if not isinstance(series[k], dict) else series[k]
        if not s:
            continue
        rows += 1
        lines.append(f"| {k} | {s['n']} | {s['mean']:.{prec}f} | {s['median']:.{prec}f} | "
                     f"{s['max']:.{prec}f} | {s['min']:.{prec}f} |")
    if not rows:
        lines.append("| _无可用数据_ | | | | | |")
    lines.append("")
    return lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data_dir")
    ap.add_argument("--out", default=None)
    ap.add_argument("--baseline", default="01-idle-baseline")
    args = ap.parse_args()

    files = sorted(p for p in glob.glob(os.path.join(args.data_dir, "*.jsonl"))
                   if "_orchestration" not in p and not os.path.basename(p).startswith("temp-"))
    if not files:
        print(f"no scenario JSONL under {args.data_dir}", file=sys.stderr)
        return 2

    data = {os.path.basename(p).rsplit(".", 1)[0]: collect(load(p)) for p in files}

    temps = {}
    for p in sorted(glob.glob(os.path.join(args.data_dir, "temp-*.jsonl"))):
        base = os.path.basename(p)
        # temp-<phase>-<ts>.jsonl  -> phase key
        parts = base.split("-")
        phase = "-".join(parts[1:-1]) if len(parts) > 2 else base
        temps[phase] = collect_temp(p)

    L = ["# 受控负载功耗对照 —— 统计汇总（自动生成）", "",
         f"- 数据目录：`{args.data_dir}`", f"- 场景数：{len(files)}", ""]

    L += ["## 总览", "", "| 场景 | 样本数 | 平均采样间隔(s) | thermal_state 分布 |", "|---|---|---|---|"]
    for name, d in data.items():
        avg = f"{statistics.fmean(d['intervals']):.3f}" if d["intervals"] else "-"
        L.append(f"| {name} | {d['n']} | {avg} | {dict(d['therm']) or '-'} |")
    L.append("")

    for name, d in data.items():
        L += [f"## {name}", ""]
        L += table("SMC 功率键", {k: d["smc"].get(k, []) for k in SMC_KEYS if d["smc"].get(k)}, unit="W")
        L += table("AppleCLPC 功率", d["clpc"], unit="W")
        L += table("IOReport 功率通道（差分估计）", d["ioreport"], unit="W")
        L += table("派生：残差 / 充入电池 / USB",
                   {"residual=PDTR-充电-PDBR-PHPC-USB": d["residual"],
                    "charge_W": d["charge"], "usb_W": d["usb"]}, unit="W")
        merged_temp = dict(d.get("smctemp") or {})
        if temps:
            tkey = next((k for k in temps if name.startswith(k) or k in name), None)
            if tkey:
                for k, v in temps[tkey].items():
                    merged_temp.setdefault(k, []).extend(v)
        if merged_temp:
            L += table("芯片/电池温度（harness 源确证 M3: Te05=ECPU1 / Tf04=PCPU1 / Tf14=GPU1）",
                       merged_temp, prec=2, unit="°C")
        L += [""]

    base = data.get(args.baseline) or next((data[k] for k in data if k.startswith(args.baseline)), None)
    if base:
        L += ["## 相对 idle 的增量（mean 差值）", "",
              "| 场景 | 通道 | idle_mean | 本场景_mean | 增量 |", "|---|---|---|---|---|"]
        for name, d in data.items():
            if d is base:
                continue
            b, s = st(base["residual"]), st(d["residual"])
            if b and s:
                L.append(f"| {name} | residual | {b['mean']:.3f} | {s['mean']:.3f} | {s['mean'] - b['mean']:+.3f} |")
            for grp in ("smc", "clpc", "ioreport"):
                for k in sorted(d[grp]):
                    if k not in base[grp]:
                        continue
                    b, s = st(base[grp][k]), st(d[grp][k])
                    if b and s:
                        L.append(f"| {name} | {grp}:{k} | {b['mean']:.3f} | {s['mean']:.3f} | {s['mean'] - b['mean']:+.3f} |")
        L.append("")

    text = "\n".join(L) + "\n"
    if args.out:
        open(args.out, "w", encoding="utf-8").write(text)
        print(f"wrote {args.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
