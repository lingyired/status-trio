# load-lab 工具集（M3 Max 功耗对照实验）

研究用、只读优先、**不需要 sudo**、不安装系统组件、不写 SMC。
配套数据与分析：`docs/research/data/m3-max-macos27/`（仓库 worktree）与 `/tmp/soc-power-research/load-analysis.md`。

## 构建

```sh
make            # 产出 bin/{cpuload,gpuload,memload,labprobe,smctemp,brightness-probe}
make check      # 只做 shell/python 语法检查，不施加负载
```

## 负载生成器（都会在 SIGTERM/SIGINT 后立即退出）

| 工具 | 用法 | 说明 |
|---|---|---|
| `bin/cpuload` | `--threads N --seconds S [--label L]` | N 个忙循环线程（N≤8），依赖链浮点运算，防优化 |
| `bin/gpuload` | `--seconds S [--grid 65536] [--inner 4096]` | Metal compute，运行期 `newLibraryWithSource:` 编译 MSL，不落 .metallib、不需 xcrun metal |
| `bin/memload` | `--threads 4 --mib 256 --seconds S` | 每线程 256–512 MiB 流式读写（总内存远小于 128 GB） |
| 混合 | 同时起 `cpuload` 与 `gpuload` | `run-scenarios.sh` 的 `mixed:<threads>` |

实测（本机）：cpuload 2 线程 ≈195% CPU、6 线程 ≈580%；gpuload 使 `Device Utilization %` 从 ~63% 升到 97–99%，单次 dispatch ≈2.3 ms；memload 4×256 MiB ≈187 GB/s；SIGTERM 停机延迟 10–19 ms；退出后 `ps` 无残留。

## 辅助探针

- `bin/labprobe mono|thermal|mark <label>` —— 统一 CLOCK_MONOTONIC 基准与 thermalState。
- `bin/smctemp` —— 只读温度键侧车（**默认未在正式流程启用**；正式实验用 harness 的 Te05/Tf04/Tf14）。
- `bin/brightness-probe` —— 只读检测公开 IODisplay 亮度 API 是否可用（本机 `RESULT=NO_DISPLAY_SERVICE`）。

## 编排

```sh
./run-scenarios.sh                 # 正式实验（需先有 power-sampler）
./run-scenarios.sh --selftest      # 用 stub 采样器验证编排逻辑，不产生正式数据
```

- 阶段顺序：idle → cpu-light → cpu-medium → memory-bandwidth → recovery → gpu → mixed → recovery2；阶段间 10 s 缓冲。
- 每个负载阶段采样器多采 5 s（覆盖停载边沿），日志里标 `LOAD_END_OBSERVED`。
- 每秒记录 `ioreg` GPU 利用率、每阶段 ps 快照、thermalState 看门狗（serious/critical 立即 kill 负载并中止）。
- 亮度阶段**不执行**，输出 NOT TESTED 说明（用户禁止改系统设置）。

## 分析

```sh
./analyze.py <data-dir> --out stats.md    # 逐通道 mean/median/max/min/n
./summarize.py                            # 主表/边沿/GPU 双通道/PDTR-PSTR/残差/温度
./diagnostics.py                          # GPU 利用率、停载时间线、冻结通道统计
./write-manifest.py                       # 生成 manifest.md（含 SHA256）
```

`summarize.py` 的窗口约定：有生成器日志的阶段取 `[start_mono, stop_mono]`；idle/recovery 取文件全部样本。每行输出窗口规则与样本 n。

## 约束

无 sudo、无 SMC 写入、不改系统设置、不装软件、不抢焦点/不改亮度；数据只写约定目录，不提交 git。
