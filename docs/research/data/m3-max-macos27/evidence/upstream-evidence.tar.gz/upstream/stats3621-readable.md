https://github.com/exelban/stats/issues/3621

---

CPU Power Showing 0.00W

---

CPU Power is showing 0.00W in the Stats app instead of the actual power consumption.

**Details:**

* Device: MacBook Air M5
* macOS: 27
* App Version: 3.0.16

Please fix the CPU power sensor so it displays the correct value.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5702465324

---

exelban 2026-09-16T18:24:28Z

---

Hi, this is not a Stats-specific problem. The issue is that macOS does not report this value (or report incorrectly). I hope this is a bug that will be fixed in an upcoming macOS update. There is unfortunately nothing I can do on my side (at least, I’m not aware of any workaround at the moment).

I’m going to leave this issue open until it is fixed, mainly to prevent duplicate issues from being created.

Please do not comment unless you have new information regarding this problem.

PS: the problem is not only with the CPU Power, but will almost all powers that are fetching from the `IOReport`.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5812430290

---

homm 2026-09-24T10:32:33Z

---

@exelban What I found: When powermetrics run in background, this metric is reported correctly:

```bash
$ time sudo -n /usr/bin/powermetrics --samplers cpu_power -i 1000 -f plist > /dev/null
```

Probably we need to set some flags or call something to alter calculation. Needs more investigation 

---

https://github.com/exelban/stats/issues/3621#issuecomment-5815265390

---

exelban 2026-09-24T13:41:57Z

---

Very good, but its sudo. And its banned here

---

https://github.com/exelban/stats/issues/3621#issuecomment-5816414329

---

homm 2026-09-24T14:47:53Z

---

@exelban I’m not suggesting that Stats should run `powermetrics` or require `sudo`. I used it only to investigate why the IOReport values are zero.

On my M4 Pro with macOS 27, repeated reads of `Energy Model / CPU Energy` return zero. While a separate `sudo /usr/bin/powermetrics --samplers cpu_power -i 200` process is running, that **same IOReport channel** starts producing nonzero increments for an unprivileged reader. When `powermetrics` stops, the increments stop. Their update cadence follows the `powermetrics` sampling interval. The `gpu_power` sampler also triggers this behavior; `tasks` and `ane_power` do not.

So I’m not referring to the CPU power value printed by `powermetrics`. I’m reporting that its power sampler appears to make the underlying IOReport energy counters update for other processes. The question is what action causes those updates and whether an unprivileged process can perform it.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5816647726

---

exelban 2026-09-24T15:02:04Z

---

thx, I will take a look, maybe will find something

---

https://github.com/exelban/stats/issues/3621#issuecomment-5816975542

---

homm 2026-09-24T15:21:32Z

---

@exelban I found another clue. The system `powermetrics` binary has the private entitlement `com.apple.private.pmgr.nrg.reporting=true`:

```sh
$ codesign -d --entitlements - /usr/bin/powermetrics
Executable=/usr/bin/powermetrics
[Dict]
	[Key] com.apple.private.applegraphicsdevicecontrol
	[Value]
		[Bool] true
	[Key] com.apple.private.pmgr.nrg.reporting
	[Value]
		[Bool] true
	[Key] com.apple.system-task-ports.inspect
	[Value]
		[Bool] true
```

An ad hoc re-signed copy of `powermetrics` runs under `sudo` but reports `CPU Power: 0 mW`. It also no longer causes `Energy Model / CPU Energy` to update for a separate unprivileged IOReport reader, whereas the original binary does.

Adding that entitlement to the ad hoc-signed copy makes macOS kill it before sampling. I reproduced this with a minimal test program: without the entitlement it runs; with the entitlement it is killed before `main`.

This points to an Apple-authorized signing privilege, possibly this entitlement. It does not yet prove that this specific entitlement is the gate, since re-signing also changes the binary’s platform signing status.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5845048378

---

tianchengchi04 2026-09-26T09:30:03Z

---

I independently encountered and reported this behavior on my Mac. The technical diagnosis, patch implementation, and validation described below were performed with assistance from OpenAI Codex.

My environment:

- MacBook Air, Mac16,12
- Apple M4
- macOS 27.0 (26A428)
- Stats 3.0.17

Repeated reads of `Energy Model / CPU Energy` remain at zero, matching the behavior described in this issue.

During the technical investigation, Codex identified a device-specific fallback that works without `sudo` or private entitlements: on this base M4, the SMC key `PZC0` continues to report CPU package power and responds to load while the IOReport CPU energy counter is frozen. Measurements from my machine were approximately 1.00 W at idle and 24.02 W under load.

A scoped patch was then prepared and tested. It:

- uses `PZC0` only on macOS 27 and the base `.m4` platform;
- falls back to the existing IOReport calculation if the SMC value is unavailable, non-finite, or zero;
- removes the `prevCPU != 0` early return, because a permanently frozen CPU counter otherwise causes all IOReport-derived power values to be returned as zero on every sample;
- leaves the existing behavior unchanged on other macOS versions and platforms.

The patched app builds successfully in Release configuration and has been running locally with nonzero CPU Power readings. I have not tested this fallback on M4 Pro/Max or M5, so the patch is intentionally limited to the base M4 for now.

I plan to open a PR containing the implementation for review. The PR will also disclose that the technical diagnosis and code were prepared with assistance from OpenAI Codex.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5845159309

---

tianchengchi04 2026-09-26T09:42:34Z

---

Update: I have now published the tested patch for review:

- Commit: https://github.com/tianchengchi04/stats/commit/e6a9dbe8bbb0eb7bda588f5ab8ae0109f88f4bd8
- Full diff against upstream master: https://github.com/exelban/stats/compare/master...tianchengchi04:stats:fix/macos27-m4-cpu-power

The comparison contains one changed file (`Modules/Sensors/readers.swift`), with 21 additions and 6 deletions. GitHub reports that this repository currently limits opening pull requests to collaborators, so I cannot create the upstream PR from my account. If the approach is useful, please feel free to review or cherry-pick the commit.

The patch remains intentionally scoped to macOS 27 on the base M4. I encountered and reported the issue; the technical diagnosis, implementation, and validation were completed with assistance from OpenAI Codex.

---

https://github.com/exelban/stats/issues/3621#issuecomment-5856657683

---

STRML 2026-09-27T14:20:01Z

---

There's a no-root source for CPU power on macOS 27: the PMP IOReport group has per-cluster power histograms that keep counting while `Energy Model / CPU Energy` is frozen. Fix is here, PRs are collaborator-only so I can't open one: https://github.com/exelban/stats/compare/master...STRML:osx-stats:fix/m5-ultra-power

```
PMP0 / Energy / PACC        states "2W" "4W" ... "32W", residency = time
PMP0 / Energy / MACC0 SRAM  states "0.250W" ...
```

CPU W = sum over clusters of the residency-weighted bin label, with the lowest bin read as 0 (an idle cluster sits in "2W" 100% of the time). Checked against the one counter that still works: the GPU's `AGX` histogram read this way averaged 62.2 W vs 63.5 W from `GPU Energy` over the same 8 s on an M5 Ultra. And against powermetrics' own CPU number: its sampler makes `CPU Energy` live, so over 30 s on an M5 Max that counter averaged 13.76 W vs 14.36 W from the histograms (+4.3%, r = 0.93, 3-33 W of load).

The same branch fixes four more things:

| Symptom | Cause |
|---|---|
| every IOReport power reads 0, GPU included | `guard prevCPU != 0` never passes once CPU energy is frozen |
| only the last die counts for CPU/ANE/DRAM on Ultra | per-die channels (`DIE_0_CPU Energy`, `DIE_1_CPU Energy`, `ANE0_0`, `ANE0_1`) overwrite instead of sum |
| RAM Power 0 W | `Energy Model / DRAM*` is gated too; SMC `PZD1` (plus `PZD2` on Ultra, one per die) tracks DRAM: 1.8 W idle, 5.9 / 8.0 / 12.8 / 14.0 W with 1 / 2 / 4 / 8 memory-streaming threads, 1.8 W under compute-only load |
| System Total 0 W on Mac Studio | `PSTR` reads 0; `PD0R` (DC-in rail = the internal PSU) is live, 27 W idle / 181 W loaded |

On M5 the PMP group is split per die (`PMP0`, `PMP1`) and bare `PMP` is empty, even on an M5 Max. Also, `Energy Model / CPU Energy` isn't fully dead: it advances over partial windows while Activity Monitor is open, which gives low, jumpy readings (0.6-14 W from sample to sample on a busy M5 Max). The branch latches the PMP source on the first 0 so the value doesn't flap. `PZC0` from the M4 patch above isn't CPU on an Ultra (it reads 120+ W there).

Tested on an M5 Ultra Mac Studio and an M5 Max MBP, macOS 27.0 (26A428). Same fix for mactop: https://github.com/metaspartan/mactop/pull/98


---

https://github.com/exelban/stats/issues/3621#issuecomment-6101687692

---

Igradi 2026-10-10T20:08:44Z

---

New data point: @STRML's branch works on a **base M5** (so far it was tested on M5 Max and Ultra only).

**Setup:** MacBook Air (Mac17,3), Apple M5, macOS 27.0.1 (26A434), Stats 3.0.20.

**What I did:** cherry-picked the two commits from `STRML:osx-stats:fix/m5-ultra-power` onto current master (5df2400). One trivial whitespace conflict in `Modules/Sensors/readers.swift`, nothing else. Release build runs and CPU Power shows live, non-zero values.

**Base M5 specifics**

- The histograms are in the bare `PMP` group here (not `PMP0`/`PMP1`): `PMP / Energy / PACC0`, `PACC0 SRAM`, `EACC0`, `EACC0 SRAM`, `AGX`, `AGX SRAM`, 32 states each. The branch already handles this.
- Bin width is 1 W for `PACC0` and 0.25 W for `EACC0`, so idle readings are coarse on this chip.
- `Energy Model / CPU Energy` is not 0 on this machine. It holds a non-zero value that stays frozen, so the delta is 0. The `cpu <= 0` check in the branch still catches it.

**Numbers**

| | PMP histograms (as in the branch) | `powermetrics` CPU Power |
|---|---|---|
| Idle | ~0.6–0.7 W | 0.16–0.43 W |
| 4 × `yes` on P-cores | 17.9–20.3 W | 18.8–19.4 W |

These were separate runs, not simultaneous, and the Air throttles under sustained load, so treat it as a sanity check rather than a calibration.

**How the gating behaves here**

- While `sudo powermetrics --samplers cpu_power` runs, an unprivileged reader sees `CPU Energy` advance correctly (+38.9 J per 2 s = 19.4 W, same as powermetrics printed). It freezes again when powermetrics exits.
- It also jumps about every 30 minutes, at the moments powerlog takes its Energy Model sample. On an unpatched build that would show as 0 W with an occasional huge spike.
- Reading the channel as root without the entitlement does not help: still frozen.

**SMC on base M5, in case it is useful**

- `PZC0` (used in the M4 patch above) is not CPU-only on M5. It tracks `PHPS` and includes the GPU: with a GPU-only Metal compute load it read 20.0 W while `GPU Energy` gave 18.0 W.
- `PP1b` looks like the GPU rail: 17.98 W against 18.02 W from `GPU Energy` over the same window.
- `PP0b` looks like the P-cluster rail: 18.7 W against 17.9 W from the `PACC0` histogram. `PP7b` tracks `PACC0 SRAM` (1.85 W against 2.03 W).
- `PZD1` exists and reads 0.1–0.4 W. I did not verify that it is DRAM on this machine.

<img width="550" height="1944" alt="Image" src="https://github.com/user-attachments/assets/a5f23ca5-577b-4f7c-b332-3f878bd569da" />

Investigation and testing were done with the help of Claude Code.


---

https://github.com/exelban/stats/issues/3621#issuecomment-6146808425

---

Flowershangfromthebranches 2026-10-13T13:36:38Z

---

New data point for the **base M3**, where the PMP histogram workaround above does not apply. I have a fix ready but can't open a PR (the repository limits PRs to collaborators).

**Setup:** MacBook Air M3, macOS 27.2 (26B5086k), Stats 3.0.21

**What I see**

- `Energy Model / CPU Energy` (served by `AppleT8122PMGR`) is frozen for an unprivileged reader. It stayed at 874794979 mJ for 12+ minutes, and `ECPU`, `PCPU`, `DRAM` and `ANE` are frozen too.
- Only `GPU Energy` (from `AGXAcceleratorG15G`) keeps counting.
- The frozen counter jumps about every 30 min, when powerlog samples it.
- On M3 the `PMP` group has **no `Energy` subgroup**, so the PMP histogram approach from the M4/M5 comments can't be used here.

**SMC rails that make up the CPU on M3**

I identified these with E-core-only (`taskpolicy -b`), P-core and Metal compute loads (W):

| key | idle | 4 threads on P-cores | 4 threads on E-cores | GPU compute | |
|---|---|---|---|---|---|
| `PP0b` | 0.24 | **12.21** | 0.32 | 0.25 | P-cluster |
| `PPbb` | 0.56 | 0.26 | **1.47** (0.96 / 1.14 with 1 / 2 threads) | 0.19 | E-cluster |
| `PP7b` | 0.43 | **1.87** | 0.54 | 0.18 | CPU SRAM |
| `PZC0` / `PHPC` | ~3 | ~18 | ~3.6 | **~14** | whole SoC incl. GPU, not CPU |

**Accuracy against ground truth**

I took the 1800 s window between two powerlog bumps of the frozen counter and compared it with the SMC rails integrated over the same window. The machine was mostly lightly loaded during it.

| source | average CPU power |
|---|---|
| `Energy Model / CPU Energy` | 1.577 W |
| `PP0b + PP7b + PPbb` | 1.666 W (+5.6%) |
| `PP0b + PPbb` | 1.202 W (-23.8%) |
| `PZC0` | 2.885 W (+82.9%) |

**Fix**

The fix is one commit, about 30 lines in `Modules/Sensors/readers.swift`:

- When the CPU energy delta is 0, it latches onto `PP0b + PP7b + PPbb` for good. Latching also hides the powerlog spike.
- The rails are mapped only for `.m3`. Other platforms are unchanged.
- With the patched `SensorsReader`, CPU Power reads ~1–2 W at idle and ~15–16 W with 4 threads busy on P-cores. GPU Power is unaffected.
- The app builds (Debug).

Not tested: M3 Pro / Max / Ultra (they have more clusters and probably more rails).

- Commit / branch: https://github.com/Flowershangfromthebranches/stats/tree/fix/m3-cpu-power-macos27
- Diff: https://github.com/exelban/stats/compare/master...Flowershangfromthebranches:stats:fix/m3-cpu-power-macos27

@exelban if this approach looks acceptable, feel free to cherry-pick it, or let me know if you'd prefer a different shape (e.g. a per-platform rail table in `values.swift`).

Investigation and testing were done with the help of Claude Code.


---

https://github.com/exelban/stats/issues/3621#issuecomment-6155722895

---

Igradi 2026-10-13T21:37:07Z

---

Follow-up to my comment above, prompted by @Flowershangfromthebranches' M3 data: the same three SMC rails make up the CPU on the **base M5**. One rail table could cover both `.m3` and `.m5`.

**Setup:** MacBook Air (Mac17,3), Apple M5, macOS 27.0.1 (26A434).

**Which rail responds to which load** (W, average of 4 reads). This run was on battery with Low Power Mode on, so the absolute values are low; the mapping is what matters here.

| key | idle | 4 threads on P-cores | 4 threads on E-cores (`taskpolicy -b`) | GPU compute (Metal) | |
|---|---|---|---|---|---|
| `PP0b` | 0.11–0.47 | **3.17** | 0.11 | 0.14 | P-cluster |
| `PPbb` | 0.03 | 0.09 | **0.39** | 0.02 | E-cluster |
| `PP7b` | 0.01–0.12 | **0.42** | 0.01 | 0.01 | CPU SRAM, follows the P-cluster |
| `PP1b` | 0.01 | 0.01 | 0.02 | **4.18** | GPU |
| `PZC0` / `PHPS` | 0.43–1.07 | 4.61 | 1.05 | 5.05 | whole SoC incl. GPU, not CPU |

**At full power** (on AC, Low Power Mode off, from my earlier run):

- 4 × `yes` on P-cores: `PP0b` 18.7 + `PP7b` 1.85 + `PPbb` 0.03 = 20.6 W. The PMP histograms read 20.3 W over the same seconds. `powermetrics` printed 18.8–19.4 W in a separate run.
- GPU-only load: `PP1b` 17.98 W against 18.02 W from `GPU Energy`.

So on base M5 both sources agree within a few percent under load: the PMP histograms from @STRML's branch and `PP0b + PP7b + PPbb`.

Not done on M5: a long-window comparison against the frozen counter between two powerlog bumps, like the M3 one above.

Investigation and testing were done with the help of Claude Code.


---

https://github.com/exelban/stats/issues/3621#issuecomment-6260973785

---

linq0016 2026-10-19T06:17:11Z

---

Two additional implementation/coverage data points for **Stats 3.0.22**, **Apple M5 (Mac17,2)**, **macOS 27.0.1 (26A434)**:

1. **The old `prevCPU != 0` gate is already absent in 3.0.22.** [The released code seeds the first sample using `lastIOSensorsRead`](https://github.com/exelban/stats/blob/v3.0.22/Modules/Sensors/readers.swift#L612-L623), yet CPU Power still reads 0 on this machine. Thus the earlier first-sample guard fix alone does not address this case; the frozen CPU counter still needs separate handling.

2. **Mac17,2 extends the bare-`PMP` coverage previously reported for Mac17,3.** Its CPU histograms are `PMP / Energy / PACC0`, `EACC0`, and their respective `SRAM` channels. `PMP0` through `PMP7` returned no Energy channels.

An independent unprivileged reader, using the previously described histogram calculation and excluding AGX/GPU channels, responded to a controlled load:

| Phase | PMP CPU power |
| --- | --- |
| Normal background activity, 15 s | 8.97 W mean |
| Four `yes` workers, 12 s | 21.40 W mean; 24.44 W peak |
| After stopping workers, final 10 s of recovery | 8.66 W mean |

The baseline includes background applications. This checks load response, without simultaneous `powermetrics` calibration. These measurements come from a separate diagnostic reader; the official Stats app was left unchanged. Diagnostic tooling and testing were assisted by OpenAI Codex.

---

https://github.com/exelban/stats/issues/3621#issuecomment-6396476381

---

sillygru 2026-10-25T10:25:04Z

---

New data point from a MacBook Air M2 running macOS 27.0.1 (26A434), built from source.
 
The Energy Model group behaves the same way here. CPU Energy, DRAM, ANE and the PCIe channels
(all in mJ) returned identical values across 9 s idle, 3 s of 8-core load and 12 s of
four-thread memory copying. GPU Energy (nJ) updated on every read, and PP1b moved with it on a
Metal compute loop (0.05 W idle, 4.8 W under load).
 
For RAM, PZD1 and PZD2 don't exist on this chip. PP4b and PP9b do respond to memory traffic,
going by these averages over four seconds:
 
| rail | idle | 4 threads memcpy, 4 x 160 MB | cache loop, 4 MB/thread | 4 threads ALU |
|---|---|---|---|---|
| `PP4b` | 0.24 | 1.56 | 0.25 | 0.02 |
| `PP9b` | 0.13 | 0.76 | 0.18 | 0.01 |
 
They sit near idle for loops that fit in cache and for compute-only loads, while the CPU rails
rise in all three cases, which is why I treated them as memory.
 
For CPU, PP0b read 2.45 W with four threads and 5.32 W with eight. PP7b was 0.33 and 0.41 W in
those two runs, and PPbb 0.01 and 0.72 W, which is consistent with PPbb being the E-cluster here
too. Running the same load under taskpolicy -b gave only PP0b 0.51 W and PPbb 0.07 W, so I
suspect the threads never actually moved to the E cores.
 
The branch below uses PP0b for CPU since that is the rail that dominates on M2, and reads the
IOReport delta whenever the counter does advance:
https://github.com/sillygru/stats/compare/master...fix/apple-silicon-cpu-power

Note that all of this comes from one MacBook Air M2, and the branch is a fix for that machine
only. I have not run it on M3, M4 or M5, so the rails it reads are not a general solution for
the other chips discussed in this thread.
