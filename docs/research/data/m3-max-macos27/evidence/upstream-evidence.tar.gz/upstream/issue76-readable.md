https://github.com/vladkens/macmon/issues/76

---

[macOS 27 Beta] CPU power stuck at 0.0W due to stalled AppleT6031PMGR "CPU Energy" IOReport channel

---

## What happened?

On macOS 27.0 Beta (Apple M3 Max), `cpu_power` continuously reports `0.0W` in both the TUI and `macmon pipe`. 

All other metrics—including `gpu_power`, `cpu_usage_pct`, per-core frequencies, SMC temperatures, and system power (`PSTR`)—continue to function as expected.

### Technical Root Cause

1. `macmon` calculates CPU wattage from the `Energy Model` group channels matching `"CPU Energy"` via `IOReportSimpleGetIntegerValue(delta, 0)`.
2. On Apple Silicon, `"CPU Energy"` (and related `EACC_CPU*`, `PACC_CPU*`, `DRAM0` channels) is provided by the `AppleT6031PMGR` driver.
3. Under macOS 27 Beta, `AppleT6031PMGR`'s energy counters stall/freeze across power and sleep state transitions. Sampling the raw `RawElements` dictionary payload shows that consecutive samples contain identical timestamps and counter bytes:
   - Sample 1 and Sample 2 return identical raw byte sequences for `CPU Energy`.
   - The resulting delta is `0`, causing `IOReportSimpleGetIntegerValue(delta, 0)` to return `0` (`0.00 W`).
4. In contrast, `GPU Energy` is provided by the graphics driver (`AGXAcceleratorG15X`), which continues to increment and report active wattage. Similarly, `CPU Stats :: CPU Core Performance States` residency tick counters continue advancing normally.

### Comparison to `powermetrics`
Apple's `/usr/bin/powermetrics` does not rely on the simple `CPU Energy` counter from `IOReport`. Instead, it derives CPU power dynamically from active frequency state residency deltas (`CPU Complex / Core Performance States`) weighted by the DVFS power curves.

### Environment
- **macmon:** 0.8.2
- **Hardware:** Apple M3 Max (Mac15,10 - 10P + 4E)
- **OS:** macOS 27.0 Beta (Build 26A5425a)

<details>
<summary>macmon report</summary>

```text
macmon 0.8.2 | OS: macOS 27.0 (26A5425a)

--- Hardware -------------------------------------------------------------------
         Profiler             Native
Chip     Apple M3 Max         Apple M3 Max
Model    Mac15,10             Mac15,10
Memory   36 GB                36 GB
CPU      4E + 10P             4E + 10P
GPU      30 cores             30 cores

--- Memory ---------------------------------------------------------------------
RAM  used=25690554368 bytes total=38654705664 bytes
Swap used=0 bytes total=0 bytes

--- IOReport (Excerpt) ---------------------------------------------------------
Energy Model ::  :: CPU Energy (mJ, subscribed) = 0.00W
Energy Model ::  :: GPU Energy (nJ, subscribed) = 0.85W
CPU Stats :: CPU Core Performance States :: ECPU000 (24Mticks, subscribed) = ...
CPU Stats :: CPU Core Performance States :: PCPU000 (24Mticks, subscribed) = ...

--- SMC system sensors ---------------------------------------------------------
PSTR=43.94W
```

</details>


---

https://github.com/vladkens/macmon/issues/76#issuecomment-5652877343

---

Yue-Zhengyuan 2026-09-13T11:05:51Z

---

May I ask if you have reported the bug to Apple via Feedback Assistant? I have M1 Pro chip and also encountered the bug.

---

https://github.com/vladkens/macmon/issues/76#issuecomment-5673284728

---

roely15mol 2026-09-15T01:29:26Z

---

No, did not report to Apple. Forgot to do so. But I think this might be by design as the drivers change with every release. 

---

https://github.com/vladkens/macmon/issues/76#issuecomment-5673507254

---

roely15mol 2026-09-15T01:57:42Z

---

@Yue-Zhengyuan added a fix for M3 Max, but it's processor specific. 

---

https://github.com/vladkens/macmon/issues/76#issuecomment-5673696377

---

Yue-Zhengyuan 2026-09-15T02:21:52Z

---

Honestly I think it may be better to let Apple address the upstream issue first.

On the repo of `stats` (https://github.com/exelban/stats), there are many reports of zero reading of CPU power on many Apple Silicon Macs, ranging from M1 to [M5](https://github.com/exelban/stats/issues/3399) and even [A18 Pro](https://github.com/exelban/stats/issues/3336). So I assume this bug affects all Apple Silicon Macs, and a specific fix for M3 Max is certainly not ideal.

---

https://github.com/vladkens/macmon/issues/76#issuecomment-5674746593

---

roely15mol 2026-09-15T04:29:28Z

---

Opened a feedback case with Apple few minutes ago, will have to see what they have to say about it. 

---

https://github.com/vladkens/macmon/issues/76#issuecomment-5969767570

---

talkstream 2026-10-03T13:46:10Z

---

Same on the release build and on M3 Pro, plus one detail that may help: once, the stalled counter seems to have caught up in a single sample.

**Environment:** macmon 0.8.2 · Apple M3 Pro (Mac15,6, T6030, 6E + 5P) · macOS 27.0.1 (26A434, release) and earlier 27.0 (26A428).

**1. `cpu_power` is 0.0 W on T6030 too.** 30 samples of `macmon pipe -s 30 -i 2000` on 27.0.1: `cpu_power` = 0.0 in all 30, while `gpu_power` (up to 0.47 W), `sys_power` (median 9.3 W) and temperatures move. In `macmon debug` every mJ channel of the Energy Model group reads 0.00W (`ECPU`, `PCPU`, `*_SRAM`, `ECPUDTL*`, `CPU Energy (mJ, subscribed)`, also the GPU (mJ) and DRAM channels); only `GPU Energy (nJ)` moves.

**2. Once, the stalled counter appears to have caught up in a single interval.** In a 10-minute series on 27.0 (`macmon pipe -i 2000`, 300 samples) `cpu_power` was 0.0 in 299 samples, and in exactly one (sample 5) it was **3,564.0 W** (`sys_power` showed 3,564.3 W too, since it is max(PSTR, all_power)). That matches a counter that is frozen for a while and then advances by the whole accumulated energy at once, so the delta lands in one interval. In that same sample `ram_power` was 1,011.9 W and `ane_power` 0.257 W, both 0 in the other 299, so several counters seem to catch up together. For consumers, one such sample doubled the mean `sys_power` of the whole series (22.9 W, against 11.0 W without that sample; median 10.0 W) and dominates short windows; a median, or dropping samples above a physical ceiling, avoids that until the root cause is fixed.

**3. Minor, possibly unrelated:** the Profiler column of `macmon debug` reads `CPU 6P + 0S`, while Native reads `6E + 5P` (correct for this chip).

Happy to run any build or debug command if useful.


---

https://github.com/vladkens/macmon/issues/76#issuecomment-6046222854

---

vladkens 2026-10-07T20:27:28Z

---

[v0.9.0](https://github.com/vladkens/macmon/releases/tag/v0.9.0) is out with a rootless workaround for CPU/ANE power readings on supported Macs running macOS 27, using AppleCLPC counters. Please give it a try on the machines reported here and let me know if the readings are still stuck at zero.


---

https://github.com/vladkens/macmon/issues/76#issuecomment-6051866387

---

Yue-Zhengyuan 2026-10-08T03:56:47Z

---

macOS 27.0 (26A428) on M1 Pro now works! CPU, GPU and ANE readings are all normal.

---

https://github.com/vladkens/macmon/issues/76#issuecomment-6053760346

---

roely15mol 2026-10-08T06:22:40Z

---

Works on m3 max as well thanks!