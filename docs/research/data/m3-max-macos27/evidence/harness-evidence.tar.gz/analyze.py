#!/usr/bin/env python3
"""Offline read-only analysis of the harness artifacts; writes only sibling summaries."""
import csv,json,statistics,math,pathlib
ROOT=pathlib.Path(__file__).resolve().parent

def rows(name):
    return [json.loads(x) for x in (ROOT/name).read_text().splitlines() if x]
def describe(xs):
    xs=[x for x in xs if x is not None]
    if not xs:return None
    return {'n':len(xs),'min':min(xs),'median':statistics.median(xs),'mean':statistics.mean(xs),'max':max(xs),'pstdev':statistics.pstdev(xs)}
def corr(x,y):
    if len(x)<2:return None
    mx,my=statistics.mean(x),statistics.mean(y)
    den=math.sqrt(sum((v-mx)**2 for v in x)*sum((v-my)**2 for v in y))
    return sum((a-mx)*(b-my) for a,b in zip(x,y))/den if den else None

def summary(rs):
    smcs=[]
    for first in rs[0]['smc']:
        key=first['key']; pairs=[(r['ts_mono'],next(c for c in r['smc'] if c['key']==key)) for r in rs]
        vals=[d.get('value') for _,d in pairs]; changes=[pairs[i][0] for i in range(1,len(pairs)) if vals[i]!=vals[i-1]]
        smcs.append({'key':key,'first':first,'last':pairs[-1][1], 'range':describe(vals), 'changes':len(changes),'distinct':len(set(vals)), 'change_interval_s':describe([b-a for a,b in zip(changes,changes[1:])]),'classification':('NOT AVAILABLE' if vals[0] is None else 'zero throughout; true physical zero NOT PROVEN' if set(vals)=={0} else 'unchanged observed window' if len(set(vals))==1 else 'changing')})
    channels=[]
    for first in rs[0]['ioreport']['channels']:
        ident=first['id']; series=[next(c for c in r['ioreport']['channels'] if c['id']==ident) for r in rs]
        vals=[c.get('raw_count') for c in series]
        d={k:first[k] for k in ['group','subgroup','channel','unit','format','channel_id_hex','id','descriptor_origin']}
        if all(v is not None for v in vals):
            diffs=[b-a for a,b in zip(vals,vals[1:])]
            d.update(first_count=str(vals[0]),last_count=str(vals[-1]),delta_count=str(vals[-1]-vals[0]),distinct=len(set(vals)),changes=sum(x!=0 for x in diffs),decreases=sum(x<0 for x in diffs),status='frozen (count unchanged)' if len(set(vals))==1 else 'count changed',power_w_estimate=describe([c.get('power_w_estimate') for c in series]))
        else:d['status']='NOT TESTED: non-simple format'
        channels.append(d)
    battery=[]
    firsttele=rs[0]['pmset_batt'].get('PowerTelemetryData',{})
    for key,v in firsttele.items():
        if not isinstance(v,(int,float)):continue
        vals=[r['pmset_batt'].get('PowerTelemetryData',{}).get(key) for r in rs]
        if all(isinstance(v,(int,float)) for v in vals):
            battery.append({'key':key,'first':vals[0],'last':vals[-1],'delta':vals[-1]-vals[0],'distinct':len(set(vals)),'range':describe(vals),'changes':sum(a!=b for a,b in zip(vals,vals[1:]))})
    pdtr=[next(c['value'] for c in r['smc'] if c['key']=='PDTR') for r in rs]
    teles=[r['pmset_batt'].get('PowerTelemetryData',{}) for r in rs]
    inputs=[t.get('SystemPowerIn',0) for t in teles]
    ratios=[v/p for v,p in zip(inputs,pdtr) if p]
    vi=[t.get('SystemVoltageIn',0)*t.get('SystemCurrentIn',0)/1000 for t in teles]
    ratiosvi=[a/b for a,b in zip(vi,inputs) if b]
    return {'sample_count':len(rs),'first_wall':rs[0]['ts_wall'],'last_wall':rs[-1]['ts_wall'],'span_s':rs[-1]['ts_mono']-rs[0]['ts_mono'],'smc':smcs,'channels':channels,'telemetry':battery,'telemetry_pdtr':{'SystemPowerIn_div_PDTR':describe(ratios),'corr_no_lag':corr(inputs,pdtr),'VI_div_SystemPowerIn':describe(ratiosvi),'corr_VI_power':corr(vi,inputs),'first_VI_div_1000':vi[0],'first_SystemPowerIn':inputs[0]},'timing':{'interval_s':describe([r['sampling']['interval_s'] for r in rs]),'lateness_s':describe([r['sampling']['lateness_s'] for r in rs]),'sample_read_duration_s':describe([r['sample_read_duration_s'] for r in rs])},'thermal_states':sorted(set(r['thermal_state'] for r in rs)),'clpc_properties_first':rs[0]['clpc']['properties'],'clpc_properties_last':rs[-1]['clpc']['properties']}

if __name__=='__main__':
    output={}
    for name in ['smc-tick-10hz.jsonl','temperature-tick-10hz.jsonl','freeze-1hz-60s.jsonl','sample-idle.jsonl']:
        if (ROOT/name).exists(): output[name]=summary(rows(name))
    (ROOT/'analysis-summary.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    if 'freeze-1hz-60s.jsonl' in output:
        cs=output['freeze-1hz-60s.jsonl']['channels']
        fields=['group','subgroup','channel','unit','format','channel_id_hex','first_count','last_count','delta_count','distinct','changes','decreases','status']
        with (ROOT/'channel-freeze-matrix.csv').open('w') as f:
            w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader();w.writerows(cs)
    print(json.dumps({name:{'samples':s['sample_count'],'span_s':s['span_s'],'channels_changed':sum(c['status']=='count changed' for c in s['channels']),'channels_frozen':sum(c['status']=='frozen (count unchanged)' for c in s['channels']),'timing':s['timing'],'telemetry_pdtr':s['telemetry_pdtr']} for name,s in output.items()},ensure_ascii=False,indent=2))
